# DN AI Chat — Gemini Free-Tier version

Render settings:
Build Command: npm install
Start Command: npm start

Environment Variables:
GEMINI_API_KEY = your Gemini API key
GEMINI_MODEL = gemini-2.5-flash-lite

Never upload a real API key to GitHub. Keep it in Render Environment Variables.
