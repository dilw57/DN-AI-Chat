# DN AI Chat — Ready to Deploy

## Included
- `public/index.html` — DN AI Chat frontend
- `server.js` — secure backend proxy
- `package.json` — Node.js dependencies
- `.env.example` — environment-variable template

## Important
Never put your OpenAI API key in the frontend/browser code or commit it to GitHub. Set `OPENAI_API_KEY` as a server environment variable.

## Run locally
1. Install Node.js.
2. Open this folder in a terminal.
3. Run `npm install`
4. Set `OPENAI_API_KEY` in your environment.
5. Run `npm start`
6. Open `http://localhost:3000`

Optional: set `OPENAI_MODEL` to a model available to your API project. The default is `gpt-6-luna`.

## Deploy
Use any Node.js host that supports environment variables.
Set:
- `OPENAI_API_KEY` = your secret key
- `OPENAI_MODEL` = optional model

Start command:
`npm start`

For Google Sites, embed the URL of the deployed DN AI Chat site. Keep the API key on the backend.
