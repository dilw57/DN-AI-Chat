const express=require("express");
const path=require("path");
const OpenAI=require("openai");
const app=express();
const port=process.env.PORT||3000;
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

app.post("/api/chat",async(req,res)=>{
 try{
  const message=typeof req.body?.message==="string"?req.body.message.trim():"";
  if(!message)return res.status(400).json({error:"Message is required."});
  if(message.length>12000)return res.status(413).json({error:"Message is too long."});
  if(!process.env.OPENAI_API_KEY)return res.status(500).json({error:"AI backend is not configured yet."});
  const response=await client.responses.create({
   model:process.env.OPENAI_MODEL||"gpt-6-luna",
   instructions:"You are DN AI, a helpful, clear and friendly AI assistant. Keep answers appropriate for a general audience.",
   input:[{role:"user",content:message}]
  });
  res.json({reply:response.output_text||"I couldn't generate a response."});
 }catch(error){console.error(error);res.status(500).json({error:"The AI request failed. Check the server logs."});}
});
app.listen(port,"0.0.0.0",()=>console.log("DN AI Chat running on port "+port));
